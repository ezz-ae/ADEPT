# Dev Quickstart

## Foundry
- `cd contracts/foundry`
- `forge install foundry-rs/forge-std`
- `forge test -vv`

## What the tests cover
- **Genesis.t.sol** — minting and Born event emission for the SBT mock.
- **Transcript.t.sol** — recording an ExamResult and event emission.
- **OwnerRegistry.t.sol** — ban/suspend toggling on a mock registry.

These scaffold tests ensure your event signatures, structs, and basic flows are wired correctly.
