#!/usr/bin/env python3
import argparse, json, hashlib

def hex32(h): 
    if h.startswith("0x"): h = h[2:]
    return "0x"+h.lower()

def sha256(s: str) -> str:
    return "0x" + hashlib.sha256(s.encode("utf-8")).hexdigest()

parser = argparse.ArgumentParser(description="Verify Adept receipt hashes against policy registry entries.")
parser.add_argument("--policy-hash", required=True)
parser.add_argument("--coex-hash", required=True)
parser.add_argument("--artifact-hash", required=True)
parser.add_argument("--concat", help="Optional raw concatenation to hash and compare", default=None)

args = parser.parse_args()
print("[*] PolicyHash:", args.policy_hash)
print("[*] CoExHash:   ", args.coex_hash)
print("[*] ArtifactHash:", args.artifact_hash)
if args.concat:
    h = sha256(args.concat)
    print("[*] sha256(concat) =", h)
