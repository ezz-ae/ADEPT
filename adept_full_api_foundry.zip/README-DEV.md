# Adept Network — Full API + Foundry Scaffold
**Date:** 2025-08-30

This package includes:
- **api/openapi.yaml** — full OpenAPI v1 (production names).
- **contracts/foundry/** — Foundry scaffold with interfaces, mock implementations, and tests.
- **cli/verify_receipt.py** — simple offline verifier helper for policy/coex/artifact hashes.
- **docs/** quickstart.

## Quickstart (Foundry)
1. Install Foundry: https://book.getfoundry.sh/getting-started/installation
2. `cd contracts/foundry`
3. Install test deps: `forge install foundry-rs/forge-std`
4. Run tests: `forge test -vv`

## Quickstart (API docs)
Open `api/openapi.yaml` in Redocly, Swagger UI, or your gateway docs.

## Notes
- Mock contracts are for tests only (non-production). They exercise the events/structs and allow you to start wiring services.
